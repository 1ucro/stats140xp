library(tidyverse)
data1 <- read_csv("final_data_of_interest.csv")

df <- tibble(variable = colnames(data1), KS_p=rep(NA,ncol(data1)) ,KS_D=rep(NA,ncol(data1)), reg_p_kendall=rep(NA,ncol(data1)), reg_z_kendall=rep(NA,ncol(data1)), reg_tau_kendall=rep(NA,ncol(data1)), reg_p_spearman=rep(NA,ncol(data1)), reg_S_spearman=rep(NA,ncol(data1)), reg_rho_spearman=rep(NA,ncol(data1)), turnout_p_kendall=rep(NA,ncol(data1)), turnout_z_kendall=rep(NA,ncol(data1)), turnout_tau_kendall=rep(NA,ncol(data1)), turnout_p_spearman=rep(NA,ncol(data1)), turnout_S_spearman=rep(NA,ncol(data1)), turnout_rho_spearman=rep(NA,ncol(data1)), reg_sig_kendall=rep(NA,ncol(data1)), reg_sig_spearman=rep(NA,ncol(data1)), turnout_sig_kendall=rep(NA,ncol(data1)),turnout_sig_spearman=rep(NA,ncol(data1)))

for (i in 4:ncol(data1)) {
  var_i <- data1[i] %>% drop_na() %>% unlist() # Variable in question
  qqnorm(var_i,main=colnames(data1)[i]) # Q-Q Norm plot for variable
  
  ks_i <- ks.test(var_i,"pnorm",mean(var_i),sd(var_i)) # K-S test results
  df$KS_p[i] <- ks_i$p.value
  df$KS_D[i] <- ks_i$statistic
}

for (i in 6:ncol(data1)) {
  data_subset <- data1[c(4,5,i)] %>% drop_na() # Removes rows from voter reg and turnout for which the variable in question has an NA value
  reg_kendall <- cor.test(data_subset[3] %>% unlist(),data_subset[1] %>% unlist(),method="kendall")
  
  ##### Voter Registration Kendall Test #####
  
  df$reg_p_kendall[i] <- reg_kendall$p.value
  df$reg_z_kendall[i] <- reg_kendall$statistic
  df$reg_tau_kendall[i] <- reg_kendall$estimate
  
  if (reg_kendall$p.value<.05) {
    df$reg_sig_kendall[i] <- TRUE
  } else {
    df$reg_sig_kendall[i] <- FALSE
  }
  
  ##### Voter Registration Spearman Test #####
  
  reg_spearman <- cor.test(data_subset[3] %>% unlist(),data_subset[1] %>% unlist(),method="spearman")
  
  df$reg_p_spearman[i] <- reg_spearman$p.value
  df$reg_S_spearman[i] <- reg_spearman$statistic
  df$reg_rho_spearman[i] <- reg_spearman$estimate
  
  if (reg_spearman$p.value<.05) {
    df$reg_sig_spearman[i] <- TRUE
  } else {
    df$reg_sig_spearman[i] <- FALSE
  }
  
  ##### Voter Turnout Kendall Test #####
  
  turnout_kendall <- cor.test(data_subset[3] %>% unlist(),data_subset[2] %>% unlist(),method="kendall")
  
  df$turnout_p_kendall[i] <- turnout_kendall$p.value
  df$turnout_z_kendall[i] <- turnout_kendall$statistic
  df$turnout_tau_kendall[i] <- turnout_kendall$estimate
  
  if (turnout_kendall$p.value<.05) {
    df$turnout_sig_kendall[i] <- TRUE
  } else {
    df$turnout_sig_kendall[i] <- FALSE
  }
  
  ##### Voter Turnout Spearman Test #####
  
  turnout_spearman <- cor.test(data_subset[3] %>% unlist(),data_subset[2] %>% unlist(),method="spearman")
  
  df$turnout_p_spearman[i] <- turnout_spearman$p.value
  df$turnout_S_spearman[i] <- turnout_spearman$statistic
  df$turnout_rho_spearman[i] <- turnout_spearman$estimate
  
  if (turnout_spearman$p.value<.05) {
    df$turnout_sig_spearman[i] <- TRUE
  } else {
    df$turnout_sig_spearman[i] <- FALSE
  }
  
}

df <- df %>% slice(-(1:3))

write_csv(df, file="test_outputs.csv")