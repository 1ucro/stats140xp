```python
import pandas as pd
import numpy as np
import urllib
from matplotlib import pyplot as plt
import seaborn as sns
```


```python
fis_health = pd.read_csv("final_data_ip.csv")
```


```python
fis_health
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city_name</th>
      <th>overall_risk</th>
      <th>general_fund_reserves_risk</th>
      <th>debt_burden_risk</th>
      <th>liquidity_risk</th>
      <th>revenue_trends_risk</th>
      <th>pension_obligations_risk</th>
      <th>pension_funding_risk</th>
      <th>pension_costs_risk</th>
      <th>future_pension_costs_risk</th>
      <th>...</th>
      <th>democratic</th>
      <th>republican</th>
      <th>american_independent</th>
      <th>green</th>
      <th>libertarian</th>
      <th>peace_and_freedom</th>
      <th>unknown</th>
      <th>other</th>
      <th>no_party_preference</th>
      <th>AMI</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adelanto</td>
      <td>Moderate</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>...</td>
      <td>450725.0</td>
      <td>328307.0</td>
      <td>42655.0</td>
      <td>3437.0</td>
      <td>10315.0</td>
      <td>6782.0</td>
      <td>6675.0</td>
      <td>6643.0</td>
      <td>247148.0</td>
      <td>87400.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Agoura Hills</td>
      <td>Low</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>...</td>
      <td>3048960.0</td>
      <td>996999.0</td>
      <td>143054.0</td>
      <td>22483.0</td>
      <td>41081.0</td>
      <td>35228.0</td>
      <td>39687.0</td>
      <td>35505.0</td>
      <td>1450170.0</td>
      <td>91100.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Alameda</td>
      <td>Moderate</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>HIGH</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>...</td>
      <td>574959.0</td>
      <td>106702.0</td>
      <td>19331.0</td>
      <td>5249.0</td>
      <td>5745.0</td>
      <td>3543.0</td>
      <td>91.0</td>
      <td>5521.0</td>
      <td>245668.0</td>
      <td>142800.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albany</td>
      <td>Moderate</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>HIGH</td>
      <td>...</td>
      <td>574959.0</td>
      <td>106702.0</td>
      <td>19331.0</td>
      <td>5249.0</td>
      <td>5745.0</td>
      <td>3543.0</td>
      <td>91.0</td>
      <td>5521.0</td>
      <td>245668.0</td>
      <td>142800.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alhambra</td>
      <td>Moderate</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>HIGH</td>
      <td>HIGH</td>
      <td>HIGH</td>
      <td>...</td>
      <td>3048960.0</td>
      <td>996999.0</td>
      <td>143054.0</td>
      <td>22483.0</td>
      <td>41081.0</td>
      <td>35228.0</td>
      <td>39687.0</td>
      <td>35505.0</td>
      <td>1450170.0</td>
      <td>91100.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1836</th>
      <td>Yorba Linda</td>
      <td>Low</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>...</td>
      <td>648537.0</td>
      <td>606174.0</td>
      <td>50404.0</td>
      <td>5078.0</td>
      <td>17899.0</td>
      <td>5961.0</td>
      <td>2257.0</td>
      <td>4955.0</td>
      <td>431435.0</td>
      <td>119100.0</td>
    </tr>
    <tr>
      <th>1837</th>
      <td>Yountville</td>
      <td>Low</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>HIGH</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>...</td>
      <td>41749.0</td>
      <td>18434.0</td>
      <td>2773.0</td>
      <td>460.0</td>
      <td>908.0</td>
      <td>298.0</td>
      <td>528.0</td>
      <td>304.0</td>
      <td>19391.0</td>
      <td>119400.0</td>
    </tr>
    <tr>
      <th>1838</th>
      <td>Yreka</td>
      <td>Low</td>
      <td>LOW</td>
      <td>HIGH</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>...</td>
      <td>8856.0</td>
      <td>11913.0</td>
      <td>1424.0</td>
      <td>168.0</td>
      <td>397.0</td>
      <td>143.0</td>
      <td>186.0</td>
      <td>65.0</td>
      <td>6088.0</td>
      <td>80300.0</td>
    </tr>
    <tr>
      <th>1839</th>
      <td>Yuba City</td>
      <td>Moderate</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>MODERATE</td>
      <td>HIGH</td>
      <td>...</td>
      <td>15941.0</td>
      <td>21309.0</td>
      <td>1931.0</td>
      <td>122.0</td>
      <td>566.0</td>
      <td>210.0</td>
      <td>318.0</td>
      <td>3756.0</td>
      <td>7943.0</td>
      <td>80300.0</td>
    </tr>
    <tr>
      <th>1840</th>
      <td>Yucca Valley</td>
      <td>Low</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>HIGH</td>
      <td>LOW</td>
      <td>MODERATE</td>
      <td>LOW</td>
      <td>LOW</td>
      <td>...</td>
      <td>450725.0</td>
      <td>328307.0</td>
      <td>42655.0</td>
      <td>3437.0</td>
      <td>10315.0</td>
      <td>6782.0</td>
      <td>6675.0</td>
      <td>6643.0</td>
      <td>247148.0</td>
      <td>87400.0</td>
    </tr>
  </tbody>
</table>
<p>1841 rows × 71 columns</p>
</div>




```python
# population mean, debt burden points mean, liquidity points mean, and government wide revenue mean by city
fis_health.groupby(["city_name"])[['population', 'debt_burden_points', 'liquidity_points', 'government_wide_revenue']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>population</th>
      <th>debt_burden_points</th>
      <th>liquidity_points</th>
      <th>government_wide_revenue</th>
    </tr>
    <tr>
      <th>city_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Adelanto</th>
      <td>34023.666667</td>
      <td>0.000000</td>
      <td>4.633333</td>
      <td>3.498386e+07</td>
    </tr>
    <tr>
      <th>Agoura Hills</th>
      <td>20271.500000</td>
      <td>11.850000</td>
      <td>10.000000</td>
      <td>2.460832e+07</td>
    </tr>
    <tr>
      <th>Alameda</th>
      <td>78461.500000</td>
      <td>13.430000</td>
      <td>10.000000</td>
      <td>2.511588e+08</td>
    </tr>
    <tr>
      <th>Albany</th>
      <td>19934.333333</td>
      <td>10.356667</td>
      <td>9.583333</td>
      <td>3.407428e+07</td>
    </tr>
    <tr>
      <th>Alhambra</th>
      <td>84065.500000</td>
      <td>13.307500</td>
      <td>10.000000</td>
      <td>1.200751e+08</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Yountville</th>
      <td>2973.750000</td>
      <td>9.935000</td>
      <td>10.000000</td>
      <td>1.739732e+07</td>
    </tr>
    <tr>
      <th>Yreka</th>
      <td>7525.250000</td>
      <td>8.600000</td>
      <td>10.000000</td>
      <td>1.492229e+07</td>
    </tr>
    <tr>
      <th>Yuba City</th>
      <td>66678.250000</td>
      <td>8.745000</td>
      <td>8.050000</td>
      <td>1.014174e+08</td>
    </tr>
    <tr>
      <th>Yucaipa</th>
      <td>53658.000000</td>
      <td>15.000000</td>
      <td>10.000000</td>
      <td>3.544833e+07</td>
    </tr>
    <tr>
      <th>Yucca Valley</th>
      <td>21740.750000</td>
      <td>15.000000</td>
      <td>10.000000</td>
      <td>2.469848e+07</td>
    </tr>
  </tbody>
</table>
<p>477 rows × 4 columns</p>
</div>




```python
# number of missing values
fis_health.isna().sum().sum()
```




    2345




```python
# barplot of unemployment rate by overall risk
sns.barplot(data = fis_health, x = "overall_risk", y="unemployment_rate", ci = 0)
plt.show()
```


    
![png](output_5_0.png)
    



```python
# Create a plot
fig, ax = plt.subplots(figsize = (5, 4))
# Create a boxplot of unemployment rate by liquidity risk category
sns.boxplot(data = fis_health, y = "liquidity_risk", x = "unemployment_rate", hue = "liquidity_risk")
```




    <AxesSubplot:xlabel='unemployment_rate', ylabel='liquidity_risk'>




    
![png](output_6_1.png)
    



```python
# Create a plot
fig, ax = plt.subplots(figsize = (5, 4))
# Create a boxplot of unemployment rate by debt burden risk category
sns.boxplot(data = fis_health, y = "debt_burden_risk", x = "unemployment_rate", hue = "debt_burden_risk")
```




    <AxesSubplot:xlabel='unemployment_rate', ylabel='debt_burden_risk'>




    
![png](output_7_1.png)
    



```python
# Create a plot
fig, ax = plt.subplots(figsize = (5, 4))
# Create a boxplot of unemployment rate by pension_obligations_risk
sns.boxplot(data = fis_health, y = "pension_obligations_risk", x = "unemployment_rate", hue = "pension_obligations_risk")
```




    <AxesSubplot:xlabel='unemployment_rate', ylabel='pension_obligations_risk'>




    
![png](output_8_1.png)
    



```python

```
